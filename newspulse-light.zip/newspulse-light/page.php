<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<div class="container page-wrap">
    <article id="post-<?php the_ID(); ?>" <?php post_class('page-article'); ?> role="article">
        <header class="page-header">
            <h1 class="page-title"><?php the_title(); ?></h1>
            <?php newspulse_breadcrumbs(); ?>
        </header>
        <div class="page-content">
            <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
        </div>
    </article>
</div>
<?php get_footer();

