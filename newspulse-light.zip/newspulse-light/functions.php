<?php
// Newspulse Light - Core bootstrap

// Prevent direct access
if (!defined('ABSPATH')) { exit; }

// Constants
define('NEWSPULSE_VERSION', '1.0.0');
define('NEWSPULSE_DIR', get_template_directory());
define('NEWSPULSE_URI', get_template_directory_uri());

// Includes
require_once NEWSPULSE_DIR . '/inc/setup.php';
require_once NEWSPULSE_DIR . '/inc/template-functions.php';

// Enqueue styles and scripts
add_action('wp_enqueue_scripts', function () {
    if (newspulse_is_amp()) {
        return; // No CSS/JS enqueues for AMP mode; keep minimal
    }

    // CSS modular
    wp_enqueue_style('newspulse-base', NEWSPULSE_URI . '/assets/css/base.css', [], NEWSPULSE_VERSION);
    wp_enqueue_style('newspulse-layout', NEWSPULSE_URI . '/assets/css/layout.css', ['newspulse-base'], NEWSPULSE_VERSION);
    wp_enqueue_style('newspulse-components', NEWSPULSE_URI . '/assets/css/components.css', ['newspulse-layout'], NEWSPULSE_VERSION);
    wp_enqueue_style('newspulse-pages', NEWSPULSE_URI . '/assets/css/pages.css', ['newspulse-components'], NEWSPULSE_VERSION);

    // Pass accent color as CSS variable override
    $accent = get_theme_mod('newspulse_accent_color', '#e11d48');
    $inline_css = ':root{--accent:' . esc_attr($accent) . ';}';
    wp_add_inline_style('newspulse-base', $inline_css);

    // JS minimal
    wp_enqueue_script('newspulse-core', NEWSPULSE_URI . '/assets/js/core.js', [], NEWSPULSE_VERSION, true);
    wp_enqueue_script('newspulse-ui', NEWSPULSE_URI . '/assets/js/ui.js', ['newspulse-core'], NEWSPULSE_VERSION, true);
});

// Head: Fonts, SEO, Open Graph, Twitter, Canonical, JSON-LD
add_action('wp_head', function () {
    // Google Fonts: Inter, with swap and preconnect
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    $gf = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap';
    echo '<link rel="preload" as="style" href="' . esc_url($gf) . '">' . "\n";
    echo '<link rel="stylesheet" href="' . esc_url($gf) . '">' . "\n";

    // Canonical
    $canonical = newspulse_canonical_url();
    if ($canonical) {
        echo '<link rel="canonical" href="' . esc_url($canonical) . '">' . "\n";
        // Optional AMP alternate
        echo '<link rel="amphtml" href="' . esc_url(add_query_arg('amp', '1', $canonical)) . '">' . "\n";
    }

    // Meta description
    $desc = newspulse_meta_description();
    if ($desc) {
        echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
    }

    // Open Graph
    $og = newspulse_open_graph_data();
    foreach ($og as $property => $content) {
        if (!empty($content)) {
            echo '<meta property="' . esc_attr($property) . '" content="' . esc_attr($content) . '">' . "\n";
        }
    }
    // Twitter Card
    $tw = newspulse_twitter_card_data();
    foreach ($tw as $name => $content) {
        if (!empty($content)) {
            echo '<meta name="' . esc_attr($name) . '" content="' . esc_attr($content) . '">' . "\n";
        }
    }

    // JSON-LD Schema
    $jsonld = newspulse_json_ld();
    if ($jsonld) {
        echo '<script type="application/ld+json">' . wp_json_encode($jsonld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
});

// REST: Breaking and Live updates (same-origin JSON for UI refresh)
add_action('rest_api_init', function(){
    register_rest_route('newspulse/v1', '/breaking', [
        'methods'  => 'GET',
        'callback' => function(){
            $q = new WP_Query([
                'posts_per_page' => 5,
                'category_name'  => 'breaking',
                'ignore_sticky_posts' => true,
            ]);
            $items = [];
            while ($q->have_posts()){ $q->the_post();
                $items[] = ['title'=>get_the_title(),'link'=>get_permalink()];
            }
            wp_reset_postdata();
            return ['updated'=> current_time('mysql'), 'items'=>$items];
        },
        'permission_callback' => '__return_true'
    ]);
    register_rest_route('newspulse/v1', '/live', [
        'methods'  => 'GET',
        'callback' => function(){
            $q = new WP_Query([
                'posts_per_page' => 5,
                'category_name'  => 'live',
                'ignore_sticky_posts' => true,
            ]);
            $items = [];
            while ($q->have_posts()){ $q->the_post();
                $items[] = ['time'=> human_time_diff(get_post_time('U'), current_time('timestamp')) . ' ' . __('ago','newspulse'), 'text'=> get_the_title(), 'link'=> get_permalink()];
            }
            wp_reset_postdata();
            return ['updated'=> current_time('mysql'), 'items'=>$items];
        },
        'permission_callback' => '__return_true'
    ]);
});

// Customizer: logo (core), accent color, footer text
add_action('customize_register', function ($wp_customize) {
    // Accent color
    $wp_customize->add_setting('newspulse_accent_color', [
        'default'           => '#e11d48',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'refresh',
    ]);
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'newspulse_accent_color', [
        'label'   => __('Accent Color', 'newspulse'),
        'section' => 'colors',
    ]));

    // Footer text
    $wp_customize->add_section('newspulse_footer', [
        'title' => __('Footer', 'newspulse'),
    ]);
    // Footer description (short about)
    $wp_customize->add_setting('newspulse_footer_desc', [
        'default'           => get_bloginfo('description'),
        'sanitize_callback' => 'wp_kses_post',
    ]);
    $wp_customize->add_control('newspulse_footer_desc', [
        'type'    => 'textarea',
        'label'   => __('Footer Description', 'newspulse'),
        'section' => 'newspulse_footer',
    ]);

    // Column titles
    $wp_customize->add_setting('newspulse_footer_quick_title', [
        'default'           => __('Navigasi Cepat', 'newspulse'),
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('newspulse_footer_quick_title', [
        'type'    => 'text',
        'label'   => __('Quick Links Title', 'newspulse'),
        'section' => 'newspulse_footer',
    ]);
    $wp_customize->add_setting('newspulse_footer_social_title', [
        'default'           => __('Ikuti Kami', 'newspulse'),
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('newspulse_footer_social_title', [
        'type'    => 'text',
        'label'   => __('Social Title', 'newspulse'),
        'section' => 'newspulse_footer',
    ]);
    $wp_customize->add_setting('newspulse_footer_text', [
        'default'           => '© ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.',
        'sanitize_callback' => 'wp_kses_post',
    ]);
    $wp_customize->add_control('newspulse_footer_text', [
        'type'    => 'textarea',
        'label'   => __('Footer Copyright Text', 'newspulse'),
        'section' => 'newspulse_footer',
    ]);

    // Social links
    $wp_customize->add_section('newspulse_social', [
        'title' => __('Social Links', 'newspulse'),
    ]);
    $socials = [
        'twitter'  => 'Twitter/X URL',
        'facebook' => 'Facebook URL',
        'youtube'  => 'YouTube URL',
        'instagram'=> 'Instagram URL',
    ];
    foreach ($socials as $key => $label) {
        $setting = 'newspulse_social_' . $key;
        $wp_customize->add_setting($setting, [
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ]);
        $wp_customize->add_control($setting, [
            'type'    => 'url',
            'label'   => __($label, 'newspulse'),
            'section' => 'newspulse_social',
        ]);
    }
});

// Ensure images lazy-load and have alt from title if missing
add_filter('wp_get_attachment_image_attributes', function ($attr, $attachment) {
    if (empty($attr['loading'])) {
        $attr['loading'] = 'lazy';
    }
    if (empty($attr['alt'])) {
        $attr['alt'] = get_post_meta($attachment->ID, '_wp_attachment_image_alt', true);
        if (!$attr['alt']) {
            $attr['alt'] = get_the_title($attachment->ID);
        }
    }
    return $attr;
}, 10, 2);
