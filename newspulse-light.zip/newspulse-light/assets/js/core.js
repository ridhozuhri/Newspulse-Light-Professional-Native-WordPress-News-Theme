// Core: Next.js-like page transitions (vanilla)
(function(){
  if (!('fetch' in window) || !('history' in window)) return;
  if (document.body.classList.contains('amp')) return; // No PJAX on AMP

  function sameOrigin(url){
    try{ const u=new URL(url, location.href); return u.origin===location.origin; }catch(e){ return false; }
  }
  function shouldIntercept(a){
    const url=a.getAttribute('href');
    if (!url || url.startsWith('#')) return false;
    if (a.target && a.target !== '_self') return false;
    if (a.hasAttribute('download')||a.rel==='external') return false;
    if (!sameOrigin(url)) return false;
    if (url.indexOf('/wp-admin')!==-1) return false;
    return true;
  }
  async function load(url){
    try{
      const res = await fetch(url, {credentials:'same-origin'});
      const text = await res.text();
      const doc = new DOMParser().parseFromString(text, 'text/html');
      const next = doc.getElementById('main-content');
      const curr = document.getElementById('main-content');
      if (next && curr){
        curr.innerHTML = next.innerHTML;
        document.title = doc.title;
        history.pushState({}, doc.title, url);
        if (window.newspulseInit) window.newspulseInit();
        window.scrollTo({top:0, behavior:'instant'});
      }else{
        location.href = url; // Fallback
      }
    }catch(e){
      location.href = url;
    }
  }
  document.addEventListener('click', function(e){
    const a = e.target.closest('a');
    if (!a) return;
    if (!shouldIntercept(a)) return;
    e.preventDefault();
    load(a.href);
  });
  window.addEventListener('popstate', function(){
    // Simpler and robust: reload on back/forward
    location.reload();
  });
})();

