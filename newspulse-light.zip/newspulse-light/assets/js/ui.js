// Minimal UI behaviors (ticker hover handled by CSS). Re-init hook.
window.newspulseInit = function(){
  // Marquee: duplicate ticker items for seamless loop
  document.querySelectorAll('.ticker-list').forEach(function(list){
    if (!list.dataset.marqueeDup){
      list.dataset.marqueeDup = '1';
      list.innerHTML = list.innerHTML + list.innerHTML; // duplicate once
    }
  });
  // Auto-refresh breaking ticker every 5 minutes
  function refreshTicker(){
    var track = document.querySelector('.ticker-list');
    if (!track) return;
    fetch('/wp-json/newspulse/v1/breaking', {credentials:'same-origin'})
      .then(function(r){return r.json();})
      .then(function(data){
        if (!data || !data.items) return;
        var html = data.items.map(function(i){ return '<li class="ticker-item"><a href="'+i.link+'">'+i.title+'</a></li>'; }).join('');
        track.innerHTML = html + html;
      })['catch'](function(){});
  }
  setInterval(refreshTicker, 300000);

  // Dropdown touch toggle: first tap opens, second navigates
  var nav = document.querySelector('.primary-menu');
  if (nav){
    nav.querySelectorAll('li.menu-item-has-children > a').forEach(function(a){
      a.addEventListener('click', function(e){
        var li = a.parentElement;
        var submenu = li.querySelector(':scope > .sub-menu');
        if (!submenu) return;
        if (!li.classList.contains('open')){
          e.preventDefault();
          // close others at same level
          Array.from(li.parentElement.children).forEach(function(sib){ if(sib!==li) sib.classList && sib.classList.remove('open'); });
          li.classList.add('open');
        }
      });
    });
    // Pointer hover support to force open reliably on desktop
    if (window.matchMedia && window.matchMedia('(hover: hover)').matches){
      nav.querySelectorAll('li.menu-item-has-children').forEach(function(li){
        li.addEventListener('mouseenter', function(){ li.classList.add('open'); });
        li.addEventListener('mouseleave', function(){ li.classList.remove('open'); });
      });
    }
  }
  // click outside to close
  document.addEventListener('click', function(e){
    var inside = e.target.closest('.primary-menu');
    if (!inside){
      document.querySelectorAll('.primary-menu li.open').forEach(function(li){ li.classList.remove('open'); });
    }
  });
  // Header search toggle
  var hs = document.querySelector('.header-search');
  var hsBtn = hs && hs.querySelector('.util-icon.search');
  var hsForm = hs && hs.querySelector('.search-popover');
  if (hs && hsBtn && hsForm){
    hsBtn.addEventListener('click', function(e){
      // Toggle; prevent default to avoid navigation when JS is present
      e.preventDefault();
      hs.classList.toggle('open');
      if (hs.classList.contains('open')){
        var input = hs.querySelector('input[type="search"]');
        if (input) input.focus();
      }
    });
    document.addEventListener('click', function(e){
      if (!e.target.closest('.header-search')){
        hs.classList.remove('open');
      }
    });
    document.addEventListener('keydown', function(e){
      if (e.key === 'Escape') hs.classList.remove('open');
    });
  }

  // Mobile menu toggle
  var navWrap = document.querySelector('.header-nav');
  var toggle = navWrap && navWrap.querySelector('.menu-toggle');
  var menu = navWrap && navWrap.querySelector('.primary-menu');
  var backdrop = navWrap && navWrap.querySelector('.nav-backdrop');
  if (navWrap && toggle && menu){
    function closeMenu(){
      navWrap.classList.remove('open');
      toggle.setAttribute('aria-expanded','false');
    }
    function openMenu(){
      navWrap.classList.add('open');
      toggle.setAttribute('aria-expanded','true');
    }
    toggle.addEventListener('click', function(e){
      e.preventDefault();
      if (navWrap.classList.contains('open')) closeMenu(); else openMenu();
    });
    if (backdrop){ backdrop.addEventListener('click', closeMenu); }
    document.addEventListener('keydown', function(e){ if (e.key==='Escape') closeMenu(); });
    // Close on navigation click (for SPA-like pjax)
    menu.addEventListener('click', function(e){ if (e.target.closest('a')) closeMenu(); });
  }

  // Live updates (hero sidebar)
  function refreshLive(){
    var ul = document.querySelector('[data-live-feed]');
    if (!ul) return;
    fetch('/wp-json/newspulse/v1/live', {credentials:'same-origin'})
      .then(function(r){return r.json();})
      .then(function(data){
        if (!data || !data.items) return;
        ul.innerHTML = data.items.map(function(i){return '<li><span class="time">'+i.time+'</span> <a href="'+i.link+'">'+i.text+'</a></li>';}).join('');
      })['catch'](function(){});
  }
  refreshLive();
  setInterval(refreshLive, 60000);
};

// Run on first load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', window.newspulseInit);
} else {
  window.newspulseInit();
}
