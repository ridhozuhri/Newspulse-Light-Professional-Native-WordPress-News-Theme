<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<div class="container not-found">
    <h1><?php esc_html_e('404 - Not Found', 'newspulse'); ?></h1>
    <p><?php esc_html_e('Halaman tidak ditemukan. Coba kembali ke beranda.', 'newspulse'); ?></p>
    <p><a class="btn" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Kembali ke Beranda', 'newspulse'); ?></a></p>
</div>
<?php get_footer();

