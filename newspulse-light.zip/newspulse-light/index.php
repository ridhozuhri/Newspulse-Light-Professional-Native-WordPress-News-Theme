<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<div class="container content-with-sidebars">
    <aside class="sidebar sidebar-left" aria-label="Sidebar Kiri">
        <?php if (is_active_sidebar('sidebar-left')) { dynamic_sidebar('sidebar-left'); } ?>
    </aside>
    <div class="content-area">
        <?php if (is_home() || is_front_page()) : ?>
            <?php
            // HERO SECTION (simple): 1 big image + 4 titles list
            get_template_part('template-parts/content/hero', 'simple');

            // GRID BERITA
            $paged = max(1, get_query_var('paged') ?: get_query_var('page') ?: 1);
            $grid_q = new WP_Query([
                'posts_per_page' => 12,
                'paged'          => $paged,
            ]);
            if ($grid_q->have_posts()) :
                echo '<section class="news-grid">';
                while ($grid_q->have_posts()) : $grid_q->the_post();
                    get_template_part('template-parts/content/card');
                endwhile;
                echo '</section>';
                // Pagination numeric for custom query
                $big = 999999999; // need an unlikely integer
                $links = paginate_links([
                    'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $grid_q->max_num_pages,
                    'type'      => 'list',
                    'prev_text' => '«',
                    'next_text' => '»',
                ]);
                if ($links) {
                    echo '<nav class="pagination" aria-label="Pagination">' . $links . '</nav>';
                }
                wp_reset_postdata();
            else :
                echo '<p>' . esc_html__('Tidak ada berita.', 'newspulse') . '</p>';
            endif;
            ?>
        <?php else : ?>
            <?php if (have_posts()) : while (have_posts()) : the_post();
                get_template_part('template-parts/content/card');
            endwhile; else : ?>
                <p><?php esc_html_e('Tidak ada konten.', 'newspulse'); ?></p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <aside class="sidebar sidebar-right" aria-label="Sidebar Kanan">
        <?php if (is_active_sidebar('sidebar-1')) { dynamic_sidebar('sidebar-1'); } ?>
    </aside>
</div>
<?php get_footer();
