<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<div class="container content-with-sidebars">
    <aside class="sidebar sidebar-left" aria-label="Sidebar Kiri">
        <?php if (is_active_sidebar('sidebar-left')) { dynamic_sidebar('sidebar-left'); } ?>
    </aside>
    <div class="content-area">
        <header class="search-header">
            <h1><?php printf(esc_html__('Search results for: %s', 'newspulse'), esc_html(get_search_query())); ?></h1>
            <?php newspulse_breadcrumbs(); ?>
            <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
                <label>
                    <span class="sr-only"><?php esc_html_e('Search for:', 'newspulse'); ?></span>
                    <input type="search" class="search-field" placeholder="<?php esc_attr_e('Cari berita…', 'newspulse'); ?>" value="<?php echo esc_attr(get_search_query()); ?>" name="s" />
                </label>
                <button type="submit" class="btn"><?php esc_html_e('Cari', 'newspulse'); ?></button>
            </form>
        </header>
        <?php if (have_posts()) : ?>
            <section class="news-grid">
                <?php while (have_posts()) : the_post();
                    get_template_part('template-parts/content/card');
                endwhile; ?>
            </section>
            <nav class="pagination"><?php the_posts_pagination(['mid_size' => 2]); ?></nav>
        <?php else : ?>
            <p><?php esc_html_e('No results found.', 'newspulse'); ?></p>
        <?php endif; ?>
    </div>
    <aside class="sidebar sidebar-right" aria-label="Sidebar Kanan">
        <?php if (is_active_sidebar('sidebar-1')) { dynamic_sidebar('sidebar-1'); } ?>
    </aside>
</div>
<?php get_footer();
