<?php if (!defined('ABSPATH')) { exit; } ?>
<section class="hero">
    <a class="hero-link" href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
        <div class="hero-media">
            <?php if (has_post_thumbnail()) { 
                the_post_thumbnail('newspulse-hero'); 
            } else { ?>
                <div class="hero-fallback" aria-hidden="true"></div>
            <?php } ?>
            <div class="hero-overlay"></div>
            <?php $cats = get_the_category(); if ($cats) : ?>
                <span class="hero-label"><?php echo esc_html(strtoupper($cats[0]->name)); ?></span>
            <?php endif; ?>
            <div class="hero-text">
                <h2 class="hero-title"><?php the_title(); ?></h2>
                <div class="hero-meta">
                    <?php get_template_part('template-parts/content/post', 'meta'); ?>
                    <span class="sep"> · </span>
                    <span class="read-time">⏱️ <?php echo esc_html(newspulse_get_read_time_minutes()); ?> <?php esc_html_e('menit', 'newspulse'); ?></span>
                </div>
            </div>
        </div>
    </a>
</section>
