<?php if (!defined('ABSPATH')) { exit; } ?>
<section class="hero-simple">
  <?php
  $q = new WP_Query(['posts_per_page'=>5]);
  if ($q->have_posts()): $i=0; $exclude=[];
    while($q->have_posts()): $q->the_post();
      if ($i===0): $exclude[] = get_the_ID(); ?>
        <article class="hero-feature">
          <a class="media" href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
            <?php if (has_post_thumbnail()) { the_post_thumbnail('newspulse-hero'); } else { echo '<div class="hero-fallback" aria-hidden="true"></div>'; } ?>
            <span class="badge-wrap"><?php newspulse_category_badge(); ?></span>
            <span class="overlay"></span>
            <div class="caption"><h1 class="headline"><?php echo wp_trim_words(get_the_title(), 14, '…'); ?></h1></div>
          </a>
        </article>
      <?php else: // collect for list only ?>
        <?php // no output here; handled after loop ?>
      <?php endif; $i++; endwhile; wp_reset_postdata(); ?>

      <ul class="hero-list">
        <?php
        // Requery next 4 without images (list only)
        $list = new WP_Query(['posts_per_page'=>4,'post__not_in'=>$exclude]);
        while($list->have_posts()): $list->the_post(); ?>
          <li class="hero-list-item">
            <a class="hero-list-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            <span class="time"><?php echo esc_html(newspulse_time_ago()); ?></span>
          </li>
        <?php endwhile; wp_reset_postdata(); ?>
      </ul>
  <?php endif; ?>
</section>
