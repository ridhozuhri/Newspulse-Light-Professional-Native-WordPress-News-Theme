<?php if (!defined('ABSPATH')) { exit; } ?>
<span class="meta">
    <span class="author" aria-label="Author"><?php echo esc_html__('Oleh', 'newspulse'); ?> <?php newspulse_posted_by(); ?></span>
    <span class="sep"> • </span>
    <span class="date" aria-label="Date"><?php newspulse_posted_on(); ?></span>
</span>
