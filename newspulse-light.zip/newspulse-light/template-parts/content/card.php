<?php if (!defined('ABSPATH')) { exit; } ?>
<article <?php post_class('card'); ?>>
    <a class="card-link" href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
        <div class="card-thumb">
            <?php if (has_post_thumbnail()) { the_post_thumbnail('newspulse-card'); } ?>
        </div>
        <div class="card-body">
            <h3 class="card-title"><?php the_title(); ?></h3>
            <div class="card-meta"><?php get_template_part('template-parts/content/post', 'meta'); ?></div>
            <p class="card-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 20, '…')); ?></p>
        </div>
    </a>
</article>

