<?php if (!defined('ABSPATH')) { exit; }
// Only show on front page/home and hide when AMP via CSS/guard at header
$breaking = new WP_Query([
    'posts_per_page' => 5,
    'category_name'  => 'breaking',
    'ignore_sticky_posts' => true,
]);
if ($breaking->have_posts()) : ?>
<div class="breaking-ticker" role="region" aria-label="Breaking news">
    <span class="label">BREAKING</span>
    <div class="ticker-track">
        <ul class="ticker-list">
            <?php while ($breaking->have_posts()) : $breaking->the_post(); ?>
                <li class="ticker-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
            <?php endwhile; wp_reset_postdata(); ?>
        </ul>
    </div>
</div>
<?php endif; ?>

