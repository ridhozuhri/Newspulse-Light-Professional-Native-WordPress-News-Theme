<?php if (!defined('ABSPATH')) { exit; }
$url   = urlencode(get_permalink());
$title = urlencode(get_the_title());
?>
<div class="share-buttons" aria-label="Share">
    <a class="share wa" href="https://wa.me/?text=<?php echo $title; ?>%20<?php echo $url; ?>" target="_blank" rel="noopener">WhatsApp</a>
    <a class="share tw" href="https://twitter.com/intent/tweet?text=<?php echo $title; ?>&url=<?php echo $url; ?>" target="_blank" rel="noopener">Twitter</a>
    <a class="share fb" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $url; ?>" target="_blank" rel="noopener">Facebook</a>
</div>

