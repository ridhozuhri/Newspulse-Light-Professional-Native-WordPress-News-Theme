<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="header-brand">
    <?php if (function_exists('the_custom_logo') && has_custom_logo()) : ?>
        <a class="brand-logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
            <?php the_custom_logo(); ?>
        </a>
    <?php else : ?>
        <a class="brand-text" href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
    <?php endif; ?>
</div>

