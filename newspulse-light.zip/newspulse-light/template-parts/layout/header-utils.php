<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="header-utils">
    <div class="header-search" data-search>
        <a class="util-icon search" href="<?php echo esc_url(home_url('/?s=')); ?>" aria-label="<?php esc_attr_e('Cari', 'newspulse'); ?>" title="<?php esc_attr_e('Cari', 'newspulse'); ?>">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/>
                <path d="M20 20l-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
            <span class="sr-only"><?php esc_html_e('Cari', 'newspulse'); ?></span>
        </a>
        <form class="search-popover" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
            <label class="sr-only" for="hdr-search-field"><?php esc_html_e('Cari berita…', 'newspulse'); ?></label>
            <input id="hdr-search-field" type="search" name="s" placeholder="<?php esc_attr_e('Cari berita…', 'newspulse'); ?>" />
            <button type="submit" class="btn btn-search"><?php esc_html_e('Cari', 'newspulse'); ?></button>
        </form>
    </div>
    <?php if (function_exists('newspulse_social_links')) { newspulse_social_links('header'); } ?>
</div>
