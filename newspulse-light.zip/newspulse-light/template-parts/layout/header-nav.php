<?php if (!defined('ABSPATH')) { exit; } ?>
<nav class="header-nav" aria-label="Primary Navigation">
    <button class="menu-toggle" aria-expanded="false" aria-controls="primary-menu">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <span class="sr-only"><?php esc_html_e('Menu', 'newspulse'); ?></span>
    </button>
    <?php
    wp_nav_menu([
        'theme_location' => 'primary',
        'container'      => false,
        'menu_class'     => 'primary-menu',
        'menu_id'        => 'primary-menu',
        'depth'          => 3,
        'fallback_cb'    => function () {
            echo '<ul id="primary-menu" class="primary-menu">';
            wp_list_categories(['title_li' => '']);
            echo '</ul>';
        },
    ]);
    ?>
    <div class="nav-backdrop" aria-hidden="true"></div>
</nav>
