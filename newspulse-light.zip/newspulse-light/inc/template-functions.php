<?php
// Helper and template functions
if (!defined('ABSPATH')) { exit; }

function newspulse_is_amp() {
    return isset($_GET['amp']) && $_GET['amp'] == '1';
}

function newspulse_canonical_url() {
    if (is_front_page()) {
        return home_url('/');
    }
    if (is_home()) {
        return get_permalink(get_option('page_for_posts')) ?: home_url('/');
    }
    if (is_singular()) {
        return get_permalink();
    }
    if (is_category() || is_tag() || is_tax()) {
        return get_term_link(get_queried_object());
    }
    if (is_search()) {
        return get_search_link();
    }
    if (is_post_type_archive() || is_archive()) {
        return home_url(add_query_arg(NULL, NULL));
    }
    return home_url(add_query_arg(NULL, NULL));
}

function newspulse_meta_description() {
    if (is_singular()) {
        $excerpt = has_excerpt() ? get_the_excerpt() : wp_strip_all_tags(get_the_content(null, false));
        $excerpt = wp_trim_words($excerpt, 30, '…');
        return $excerpt;
    }
    return wp_trim_words(wp_strip_all_tags(get_bloginfo('description')), 30, '…');
}

function newspulse_open_graph_data() {
    $data = [
        'og:type'        => is_singular() ? 'article' : 'website',
        'og:title'       => wp_get_document_title(),
        'og:description' => newspulse_meta_description(),
        'og:url'         => newspulse_canonical_url(),
        'og:site_name'   => get_bloginfo('name'),
    ];
    if (is_singular() && has_post_thumbnail()) {
        $img = wp_get_attachment_image_src(get_post_thumbnail_id(), 'newspulse-hero');
        if ($img) { $data['og:image'] = $img[0]; }
    }
    return $data;
}

function newspulse_twitter_card_data() {
    $data = [
        'twitter:card'        => is_singular() && has_post_thumbnail() ? 'summary_large_image' : 'summary',
        'twitter:title'       => wp_get_document_title(),
        'twitter:description' => newspulse_meta_description(),
    ];
    if (is_singular() && has_post_thumbnail()) {
        $img = wp_get_attachment_image_src(get_post_thumbnail_id(), 'newspulse-hero');
        if ($img) { $data['twitter:image'] = $img[0]; }
    }
    return $data;
}

function newspulse_json_ld() {
    $site = [
        '@context' => 'https://schema.org',
        '@type'    => 'WebSite',
        'url'      => home_url('/'),
        'name'     => get_bloginfo('name'),
        'potentialAction' => [
            '@type' => 'SearchAction',
            'target' => home_url('?s={search_term_string}'),
            'query-input' => 'required name=search_term_string'
        ],
    ];
    if (is_singular('post')) {
        global $post;
        $author = get_the_author_meta('display_name', $post->post_author);
        $img = has_post_thumbnail($post) ? wp_get_attachment_image_src(get_post_thumbnail_id($post), 'newspulse-hero')[0] : '';
        $article = [
            '@context' => 'https://schema.org',
            '@type'    => 'NewsArticle',
            'mainEntityOfPage' => newspulse_canonical_url(),
            'headline' => get_the_title($post),
            'datePublished' => get_the_date(DATE_W3C, $post),
            'dateModified'  => get_the_modified_date(DATE_W3C, $post),
            'author' => [
                '@type' => 'Person',
                'name'  => $author,
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name'  => get_bloginfo('name'),
                'logo'  => [
                    '@type' => 'ImageObject',
                    'url'   => get_site_icon_url() ?: (function_exists('get_custom_logo') && has_custom_logo() ? wp_get_attachment_image_src(get_theme_mod('custom_logo'), 'full')[0] : ''),
                ],
            ],
        ];
        if ($img) { $article['image'] = $img; }
        return [$site, $article];
    }
    return $site;
}

// Clean archive titles (remove default prefixes and spans)
add_filter('get_the_archive_title', function ($title) {
    if (is_category()) {
        $title = single_cat_title('', false);
    } elseif (is_tag()) {
        $title = single_tag_title('', false);
    } elseif (is_author()) {
        $title = get_the_author();
    } elseif (is_tax()) {
        $title = single_term_title('', false);
    } elseif (is_post_type_archive()) {
        $title = post_type_archive_title('', false);
    } elseif (is_year()) {
        $title = get_the_date(_x('Y', 'yearly archives date', 'newspulse'));
    } elseif (is_month()) {
        $title = get_the_date(_x('F Y', 'monthly archives date', 'newspulse'));
    } elseif (is_day()) {
        $title = get_the_date(_x('F j, Y', 'daily archives date', 'newspulse'));
    }
    return $title;
});

function newspulse_posted_on() {
    echo '<span class="meta-date">' . esc_html(get_the_date('j F Y')) . '</span>';
}

function newspulse_posted_by() {
    echo '<span class="meta-author">' . esc_html(get_the_author()) . '</span>';
}

function newspulse_get_read_time($post_id = null) {
    $post = get_post($post_id ?: get_the_ID());
    $words = str_word_count(wp_strip_all_tags($post->post_content));
    $minutes = max(1, ceil($words / 200));
    return sprintf(_n('%s min read', '%s min read', $minutes, 'newspulse'), $minutes);
}

function newspulse_get_read_time_minutes($post_id = null) {
    $post = get_post($post_id ?: get_the_ID());
    $words = str_word_count(wp_strip_all_tags($post->post_content));
    return max(1, ceil($words / 200));
}

function newspulse_breadcrumbs() {
    echo '<nav class="breadcrumbs" aria-label="Breadcrumbs">';
    echo '<a href="' . esc_url(home_url('/')) . '">' . esc_html__('Home', 'newspulse') . '</a>';
    if (is_category() || is_single()) {
        $cats = get_the_category();
        if ($cats) {
            $cat = $cats[0];
            echo ' › <a href="' . esc_url(get_category_link($cat)) . '">' . esc_html($cat->name) . '</a>';
        }
        if (is_single()) {
            echo ' › <span class="current">' . esc_html(get_the_title()) . '</span>';
        }
    } elseif (is_archive()) {
        echo ' › <span class="current">' . esc_html(get_the_archive_title()) . '</span>';
    } elseif (is_search()) {
        echo ' › <span class="current">' . sprintf(esc_html__('Search: %s', 'newspulse'), get_search_query()) . '</span>';
    } elseif (is_page()) {
        echo ' › <span class="current">' . esc_html(get_the_title()) . '</span>';
    }
    echo '</nav>';
}

// Body class to offset header when breaking bar exists (home/front only)
add_filter('body_class', function($classes){
    if ((is_home() || is_front_page()) && !newspulse_is_amp()) {
        $classes[] = 'has-ticker';
    }
    return $classes;
});

function newspulse_time_ago($post_id = null){
    $ts = get_post_time('U', false, $post_id ?: get_the_ID());
    return human_time_diff($ts, current_time('timestamp')) . ' ' . __('ago', 'newspulse');
}

function newspulse_category_badge($post_id = null){
    $post_id = $post_id ?: get_the_ID();
    $cats = get_the_category($post_id);
    if (!$cats) return;
    $cat = $cats[0];
    if (isset($cat->slug) && $cat->slug === 'breaking') {
        return; // hide breaking badge per request
    }
    echo '<a class="cat-badge cat-' . esc_attr($cat->slug) . '" href="' . esc_url(get_category_link($cat)) . '">' . esc_html(strtoupper($cat->name)) . '</a>';
}

// Views counter: maintain 7-day rolling sum for trending
add_action('wp', function(){
    if (!is_singular('post')) return;
    if (is_user_logged_in() && current_user_can('manage_options')) {
        // Count admins too? Keep it simple and include; comment out to exclude.
    }
    $post_id = get_the_ID();
    if (!$post_id) return;
    $today = current_time('Ymd');
    // Increment total views
    $total = (int) get_post_meta($post_id, 'newspulse_views', true);
    update_post_meta($post_id, 'newspulse_views', $total + 1);
    // Increment daily key
    $day_key = 'newspulse_views_day_' . $today;
    $day_val = (int) get_post_meta($post_id, $day_key, true);
    update_post_meta($post_id, $day_key, $day_val + 1);
    // Recompute rolling 7d sum and store single meta for easy query
    $sum = 0;
    for ($i = 0; $i < 7; $i++) {
        $d = gmdate('Ymd', strtotime("-{$i} days", current_time('timestamp')));
        $sum += (int) get_post_meta($post_id, 'newspulse_views_day_' . $d, true);
    }
    update_post_meta($post_id, 'newspulse_views_7d', $sum);
});

function newspulse_social_links($context = 'header') {
    $links = [
        'twitter'  => get_theme_mod('newspulse_social_twitter', ''),
        'facebook' => get_theme_mod('newspulse_social_facebook', ''),
        'youtube'  => get_theme_mod('newspulse_social_youtube', ''),
        'instagram'=> get_theme_mod('newspulse_social_instagram', ''),
    ];
    $has_any = array_filter($links);
    if (!$has_any) {
        // Still render placeholders so user sees icons; use # and aria-disabled
        $links = [
            'twitter'  => '#',
            'facebook' => '#',
            'youtube'  => '#',
        ];
    }
    $class = $context === 'footer' ? 'social social-footer' : 'social social-header';
    echo '<ul class="' . esc_attr($class) . '">';
    foreach ($links as $key => $url) {
        if (!$url) { continue; }
        $label = ucfirst($key);
        $aria  = $url === '#' ? ' aria-disabled="true"' : '';
        $svg   = newspulse_get_social_svg($key);
        echo '<li><a class="social-link ' . esc_attr($key) . '" href="' . esc_url($url) . '" target="_blank" rel="noopener" aria-label="' . esc_attr($label) . '" title="' . esc_attr($label) . '"' . $aria . '>' . $svg . '<span class="sr-only">' . esc_html($label) . '</span></a></li>';
    }
    echo '</ul>';
}

function newspulse_get_social_svg($key){
    $common = 'width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"';
    switch ($key) {
        case 'twitter': // X logo (approx) using strokes
        case 'x':
            return '<svg '.$common.' fill="none"><path d="M4 4L20 20M20 4L4 20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
        case 'facebook':
            return '<svg '.$common.'><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89H13.56v6.988C18.343 21.128 22 16.991 22 12z"/></svg>';
        case 'youtube':
            // Based on Simple Icons YouTube glyph, monochrome
            return '<svg '.$common.'><path d="M23.498 6.186a2.99 2.99 0 0 0-2.121-2.086C19.64 3.6 12 3.6 12 3.6s-7.64 0-9.377.5A2.99 2.99 0 0 0 .502 6.186 31.515 31.515 0 0 0 0 12c0 1.938.178 3.876.502 5.814a2.99 2.99 0 0 0 2.121 2.086C4.36 20.4 12 20.4 12 20.4s7.64 0 9.377-.5a2.99 2.99 0 0 0 2.121-2.086C23.822 15.876 24 13.938 24 12s-.178-3.876-.502-5.814z"/><path d="M9.75 15.5v-7l6.5 3.5-6.5 3.5z"/></svg>';
        case 'instagram':
            // Based on Simple Icons Instagram glyph, monochrome
            return '<svg '.$common.'><path d="M12 2.163c3.204 0 3.584.012 4.85.07 1.366.062 2.633.35 3.608 1.325.975.975 1.263 2.242 1.325 3.608.058 1.266.07 1.646.07 4.85s-.012 3.584-.07 4.85c-.062 1.366-.35 2.633-1.325 3.608-.975.975-2.242 1.263-3.608 1.325-1.266.058-1.646.07-4.85.07s-3.584-.012-4.85-.07c-1.366-.062-2.633-.35-3.608-1.325-.975-.975-1.263-2.242-1.325-3.608C2.175 15.584 2.163 15.204 2.163 12s.012-3.584.07-4.85c.062-1.366.35-2.633 1.325-3.608C4.533 2.567 5.8 2.279 7.166 2.217 8.432 2.16 8.812 2.163 12 2.163zm0 1.534c-3.17 0-3.548.012-4.796.07-1.064.049-1.643.228-2.027.393-.51.198-.873.435-1.255.817-.382.382-.62.745-.817 1.255-.165.384-.344.963-.393 2.027-.058 1.248-.07 1.626-.07 4.796s.012 3.548.07 4.796c.049 1.064.228 1.643.393 2.027.198.51.435.873.817 1.255.382.382.745.62 1.255.817.384.165.963.344 2.027.393 1.248.058 1.626.07 4.796.07s3.548-.012 4.796-.07c1.064-.049 1.643-.228 2.027-.393.51-.198.873-.435 1.255-.817.382-.382.62-.745.817-1.255.165-.384.344-.963.393-2.027.058-1.248.07-1.626.07-4.796s-.012-3.548-.07-4.796c-.049-1.064-.228-1.643-.393-2.027-.198-.51-.435-.873-.817-1.255-.382-.382-.745-.62-1.255-.817-.384-.165-.963-.344-2.027-.393-1.248-.058-1.626-.07-4.796-.07zm0 3.905a5.932 5.932 0 1 1 0 11.864 5.932 5.932 0 0 1 0-11.864zm0 9.8a3.868 3.868 0 1 0 0-7.736 3.868 3.868 0 0 0 0 7.736zm5.994-10.88a1.386 1.386 0 1 1 0-2.772 1.386 1.386 0 0 1 0 2.772z"/></svg>';
        default:
            return '<svg '.$common.'><circle cx="12" cy="12" r="10"/></svg>';
    }
}
