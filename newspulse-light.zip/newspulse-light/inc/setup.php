<?php
// Theme setup and registrations
if (!defined('ABSPATH')) { exit; }

add_action('after_setup_theme', function () {
    // Core supports
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'script', 'style']);
    add_theme_support('custom-logo', [
        'height'      => 64,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    // AMP compatibility flag (used by AMP plugin if present; harmless otherwise)
    add_theme_support('amp');

    // Menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'newspulse'),
        'footer'  => __('Footer Quick Links', 'newspulse'),
    ]);

    // Image sizes
    add_image_size('newspulse-hero', 1200, 630, true);
    add_image_size('newspulse-card', 600, 338, true); // 16:9
    add_image_size('newspulse-thumb', 120, 68, true); // small 16:9 for sidebar (legacy)
    add_image_size('newspulse-thumb-sm', 80, 50, true); // tiny thumbs for popular
    add_image_size('newspulse-4x3', 240, 180, true); // 4:3 for secondary hero list
});

// Sidebar (desktop-only via CSS)
add_action('widgets_init', function () {
    register_sidebar([
        'name'          => __('Sidebar Utama', 'newspulse'),
        'id'            => 'sidebar-1',
        'before_widget' => '<section class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ]);

    register_sidebar([
        'name'          => __('Sidebar Kiri', 'newspulse'),
        'id'            => 'sidebar-left',
        'before_widget' => '<section class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ]);

    // Register Popular Posts widget
    register_widget('Newspulse_Popular_Posts_Widget');

    // Register Trending 7 Days widget
    register_widget('Newspulse_Trending_Widget');

    // Register Topics widget
    register_widget('Newspulse_Topics_Widget');

    // Register Newsletter widget
    register_widget('Newspulse_Newsletter_Widget');

    // Register Ad widget
    register_widget('Newspulse_Ad_Widget');

    // Extra widgets
    register_widget('Newspulse_Editors_Picks_Widget');
    register_widget('Newspulse_Most_Commented_Widget');
    register_widget('Newspulse_Latest_Videos_Widget');
    register_widget('Newspulse_Social_Follow_Widget');
});

// Limit sidebar to max 3 widgets on frontend
add_filter('sidebars_widgets', function ($widgets) {
    if (is_admin() || wp_doing_ajax()) { return $widgets; }
    $targets = ['sidebar-1', 'sidebar-left'];
    foreach ($targets as $sid) {
        if (!empty($widgets[$sid]) && is_array($widgets[$sid])) {
            $list = $widgets[$sid];
            $filtered = [];
            $block_opts = get_option('widget_block');
            $removed_recent = false;
            foreach ($list as $wid) {
                // Remove classic Search and Recent Comments widgets
                if (strpos($wid, 'search-') === 0 || strpos($wid, 'recent-comments-') === 0) {
                    if (strpos($wid, 'recent-comments-') === 0) { $removed_recent = true; }
                    continue;
                }
                // Drop block widgets that contain core/search or latest-comments blocks
                if (strpos($wid, 'block-') === 0 && is_array($block_opts)) {
                    $parts = explode('-', $wid);
                    $idx = end($parts);
                    if (isset($block_opts[$idx]['content']) && is_string($block_opts[$idx]['content'])) {
                        $content = $block_opts[$idx]['content'];
                        if (strpos($content, 'wp:search') !== false || strpos($content, 'wp:latest-comments') !== false) {
                            if (strpos($content, 'wp:latest-comments') !== false) { $removed_recent = true; }
                            continue;
                        }
                    }
                }
                $filtered[] = $wid;
            }
            // If recent comments removed and Popular widget not present, ensure Popular is included
            $has_popular = array_reduce($filtered, function($carry,$id){ return $carry || strpos($id, 'newspulse_popular_posts-') === 0; }, false);
            if ($removed_recent && !$has_popular) {
                $opt = get_option('widget_newspulse_popular_posts', []);
                if (!is_array($opt)) { $opt = []; }
                $n = 1; while (isset($opt[$n])) { $n++; }
                $opt[$n] = ['title' => __('Artikel Populer', 'newspulse'), 'number' => 5];
                $opt['_multiwidget'] = 1;
                update_option('widget_newspulse_popular_posts', $opt);
                $filtered[] = 'newspulse_popular_posts-' . $n;
            }
            // Limit to max 3 per sidebar
            $widgets[$sid] = array_slice(array_values($filtered), 0, 3);
        }
    }
    return $widgets;
});

// Popular Posts Widget (by comment count)
class Newspulse_Popular_Posts_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'newspulse_popular_posts',
            __('Newspulse: Artikel Populer', 'newspulse'),
            ['description' => __('Tampilkan artikel populer dengan thumbnail (berdasarkan komentar).', 'newspulse')]
        );
    }
    public function form($instance) {
        $title = isset($instance['title']) ? $instance['title'] : __('Artikel Populer', 'newspulse');
        $number = isset($instance['number']) ? absint($instance['number']) : 5;
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Judul:', 'newspulse'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Jumlah pos:', 'newspulse'); ?></label>
            <input id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number" value="<?php echo esc_attr($number); ?>" min="1" max="10" />
        </p>
        <?php
    }
    public function update($new_instance, $old_instance) {
        $instance = [];
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['number'] = absint($new_instance['number']);
        return $instance;
    }
    public function widget($args, $instance) {
        $title = isset($instance['title']) ? $instance['title'] : __('Artikel Populer', 'newspulse');
        $number = isset($instance['number']) ? absint($instance['number']) : 5;
        echo $args['before_widget'];
        if ($title) {
            echo $args['before_title'] . apply_filters('widget_title', $title) . $args['after_title'];
        }
        $q = new WP_Query([
            'posts_per_page'      => $number,
            'ignore_sticky_posts' => true,
            'orderby'             => 'comment_count',
            'order'               => 'DESC',
        ]);
        if ($q->have_posts()) {
            echo '<ul class="np-popular-list">';
            while ($q->have_posts()) { $q->the_post();
                echo '<li class="np-popular-item">';
                echo '<a class="np-popular-link" href="' . esc_url(get_permalink()) . '">';
                if (has_post_thumbnail()) {
                    echo '<span class="np-thumb">' . get_the_post_thumbnail(get_the_ID(), 'newspulse-thumb-sm') . '</span>';
                }
                echo '<span class="np-title">' . esc_html(get_the_title()) . '</span>';
                echo '</a>';
                echo '</li>';
            }
            echo '</ul>';
            wp_reset_postdata();
        } else {
            echo '<p>' . esc_html__('Belum ada artikel populer.', 'newspulse') . '</p>';
        }
        echo $args['after_widget'];
    }
}

// On theme activation: set default sidebar widgets if empty (Ad, Trending, Categories)
add_action('after_switch_theme', function(){
    $sidebars = get_option('sidebars_widgets', []);
    $list = isset($sidebars['sidebar-1']) && is_array($sidebars['sidebar-1']) ? array_filter($sidebars['sidebar-1']) : [];
    if (!empty($list)) { return; }
    // helper to create a widget instance and return its id
    $create = function($id_base, $instance){
        $opt = get_option('widget_' . $id_base, []);
        if (!is_array($opt)) { $opt = []; }
        $n = 1; while (isset($opt[$n])) { $n++; }
        $opt[$n] = $instance;
        $opt['_multiwidget'] = 1;
        update_option('widget_' . $id_base, $opt);
        return $id_base . '-' . $n;
    };
    $ad_id = $create('newspulse_ad', [
        'title' => '',
        'image' => '',
        'link'  => '',
        'size'  => '300x250',
        'html'  => '',
    ]);
    $tr_id = $create('newspulse_trending', [
        'title'  => __('Trending 7 Hari', 'newspulse'),
        'number' => 5,
    ]);
    $cat_id = $create('categories', [
        'title'        => __('Kategori', 'newspulse'),
        'count'        => 0,
        'hierarchical' => 0,
        'dropdown'     => 0,
    ]);
    $sidebars['sidebar-1'] = [$ad_id, $tr_id, $cat_id];
    update_option('sidebars_widgets', $sidebars);
});

// On theme activation: set default left sidebar if empty
add_action('after_switch_theme', function(){
    $sidebars = get_option('sidebars_widgets', []);
    $list = isset($sidebars['sidebar-left']) && is_array($sidebars['sidebar-left']) ? array_filter($sidebars['sidebar-left']) : [];
    if (!empty($list)) { return; }
    $create = function($id_base, $instance){
        $opt = get_option('widget_' . $id_base, []);
        if (!is_array($opt)) { $opt = []; }
        $n = 1; while (isset($opt[$n])) { $n++; }
        $opt[$n] = $instance;
        $opt['_multiwidget'] = 1;
        update_option('widget_' . $id_base, $opt);
        return $id_base . '-' . $n;
    };
    // Left sidebar defaults: Categories, Popular, Ad
    $cat_id = $create('categories', [
        'title'        => __('Kategori', 'newspulse'),
        'count'        => 0,
        'hierarchical' => 0,
        'dropdown'     => 0,
    ]);
    $pop_id = $create('newspulse_popular_posts', [
        'title'  => __('Artikel Populer', 'newspulse'),
        'number' => 5,
    ]);
    $ad_id  = $create('newspulse_ad', [
        'title' => '',
        'image' => '',
        'link'  => '',
        'size'  => '300x250',
        'html'  => '',
    ]);
    $sidebars['sidebar-left'] = [$cat_id, $pop_id, $ad_id];
    update_option('sidebars_widgets', $sidebars);
});

// Trending 7 Days (by rolling meta newspulse_views_7d)
class Newspulse_Trending_Widget extends WP_Widget {
    public function __construct(){
        parent::__construct('newspulse_trending', __('Newspulse: Trending 7 Hari', 'newspulse'), ['description'=>__('Artikel teratas 7 hari terakhir (berdasarkan view).', 'newspulse')]);
    }
    public function form($instance){
        $title = isset($instance['title']) ? $instance['title'] : __('Trending 7 Hari', 'newspulse');
        $number = isset($instance['number']) ? absint($instance['number']) : 5;
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Judul:', 'newspulse'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Jumlah pos:', 'newspulse'); ?></label>
            <input id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number" value="<?php echo esc_attr($number); ?>" min="1" max="10" />
        </p>
        <?php
    }
    public function update($new,$old){
        return [
            'title' => sanitize_text_field($new['title']),
            'number'=> absint($new['number'])
        ];
    }
    public function widget($args,$instance){
        $title = isset($instance['title']) ? $instance['title'] : __('Trending 7 Hari', 'newspulse');
        $number = isset($instance['number']) ? absint($instance['number']) : 5;
        echo $args['before_widget'];
        if ($title) echo $args['before_title'] . esc_html($title) . $args['after_title'];
        $q = new WP_Query([
            'posts_per_page'      => $number,
            'ignore_sticky_posts' => true,
            'meta_key'            => 'newspulse_views_7d',
            'orderby'             => 'meta_value_num',
            'order'               => 'DESC',
            'date_query'          => [ ['after' => '7 days ago'] ],
        ]);
        if (!$q->have_posts()){
            // Fallback: latest posts
            $q = new WP_Query(['posts_per_page'=>$number,'ignore_sticky_posts'=>true]);
        }
        if ($q->have_posts()){
            echo '<ul class="np-popular-list">';
            while($q->have_posts()){ $q->the_post();
                echo '<li class="np-popular-item">';
                echo '<a class="np-popular-link" href="' . esc_url(get_permalink()) . '">';
                if (has_post_thumbnail()) {
                    echo '<span class="np-thumb">' . get_the_post_thumbnail(get_the_ID(), 'newspulse-thumb-sm') . '</span>';
                }
                echo '<span class="np-title">' . esc_html(get_the_title()) . '</span>';
                echo '</a>';
                echo '</li>';
            }
            echo '</ul>';
            wp_reset_postdata();
        }
        echo $args['after_widget'];
    }
}

// Ad widget (300x250 / 300x600)
class Newspulse_Ad_Widget extends WP_Widget {
    public function __construct(){
        parent::__construct('newspulse_ad', __('Newspulse: Iklan (300x250/300x600)', 'newspulse'), ['description'=>__('Tempatkan banner iklan di sidebar (label "Iklan").', 'newspulse')]);
    }
    public function form($instance){
        $title = isset($instance['title']) ? $instance['title'] : '';
        $image = isset($instance['image']) ? $instance['image'] : '';
        $link  = isset($instance['link']) ? $instance['link'] : '';
        $size  = isset($instance['size']) ? $instance['size'] : '300x250';
        $html  = isset($instance['html']) ? $instance['html'] : '';
        ?>
        <p><label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Judul (opsional):', 'newspulse'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('image')); ?>"><?php esc_html_e('URL Gambar:', 'newspulse'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('image')); ?>" name="<?php echo esc_attr($this->get_field_name('image')); ?>" type="url" value="<?php echo esc_attr($image); ?>" placeholder="https://..." /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('link')); ?>"><?php esc_html_e('URL Tautan (opsional):', 'newspulse'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('link')); ?>" name="<?php echo esc_attr($this->get_field_name('link')); ?>" type="url" value="<?php echo esc_attr($link); ?>" placeholder="https://..." /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('size')); ?>"><?php esc_html_e('Ukuran:', 'newspulse'); ?></label>
        <select id="<?php echo esc_attr($this->get_field_id('size')); ?>" name="<?php echo esc_attr($this->get_field_name('size')); ?>" class="widefat">
            <option value="300x250" <?php selected($size,'300x250'); ?>>300x250</option>
            <option value="300x600" <?php selected($size,'300x600'); ?>>300x600</option>
        </select></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('html')); ?>"><?php esc_html_e('Custom HTML (opsional, override gambar):', 'newspulse'); ?></label>
        <textarea class="widefat" rows="4" id="<?php echo esc_attr($this->get_field_id('html')); ?>" name="<?php echo esc_attr($this->get_field_name('html')); ?>" placeholder="&lt;a href=...&gt;&lt;img ... /&gt;&lt;/a&gt;" ><?php echo esc_textarea($html); ?></textarea></p>
        <?php
    }
    public function update($new,$old){
        return [
            'title'=> sanitize_text_field($new['title']),
            'image'=> esc_url_raw($new['image']),
            'link' => esc_url_raw($new['link']),
            'size' => in_array($new['size'], ['300x250','300x600'], true) ? $new['size'] : '300x250',
            'html' => wp_kses_post($new['html']),
        ];
    }
    public function widget($args,$instance){
        $title = isset($instance['title']) ? $instance['title'] : '';
        $image = isset($instance['image']) ? $instance['image'] : '';
        $link  = isset($instance['link']) ? $instance['link'] : '';
        $size  = isset($instance['size']) ? $instance['size'] : '300x250';
        $html  = isset($instance['html']) ? $instance['html'] : '';
        echo $args['before_widget'];
        if ($title) echo $args['before_title'] . esc_html($title) . $args['after_title'];
        echo '<div class="np-ad" data-size="' . esc_attr($size) . '">';
        echo '<div class="np-ad-label">' . esc_html__('Iklan', 'newspulse') . '</div>';
        echo '<div class="ad-box">';
        if ($html) {
            echo $html; // filtered by wp_kses_post in update
        } elseif ($image) {
            $img = '<img src="' . esc_url($image) . '" alt="Ad" loading="lazy" />';
            if ($link) { $img = '<a href="' . esc_url($link) . '" target="_blank" rel="noopener">' . $img . '</a>'; }
            echo $img;
        } else {
            echo '<div class="ad-placeholder">300x250/300x600</div>';
        }
        echo '</div></div>';
        echo $args['after_widget'];
    }
}

// Editors' Picks (sticky posts or selected category)
class Newspulse_Editors_Picks_Widget extends WP_Widget {
    public function __construct(){
        parent::__construct('newspulse_editors_picks', __('Newspulse: Editor Picks', 'newspulse'), ['description'=>__('Tampilkan pilihan editor (sticky posts) atau kategori tertentu.', 'newspulse')]);
    }
    public function form($ins){
        $title = isset($ins['title']) ? $ins['title'] : __('Pilihan Editor', 'newspulse');
        $number= isset($ins['number'])? absint($ins['number']) : 5;
        $cat   = isset($ins['cat']) ? absint($ins['cat']) : 0;
        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Judul:', 'newspulse'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
        <p><label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Jumlah:', 'newspulse'); ?></label>
        <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" min="1" max="10" value="<?php echo esc_attr($number); ?>" /></p>
        <p><label for="<?php echo $this->get_field_id('cat'); ?>"><?php _e('Kategori (opsional):', 'newspulse'); ?></label>
        <?php wp_dropdown_categories(['show_option_none'=>__('– Sticky Posts –','newspulse'), 'hide_empty'=>false, 'id'=>$this->get_field_id('cat'), 'name'=>$this->get_field_name('cat'), 'selected'=>$cat]); ?></p>
        <?php
    }
    public function update($n,$o){
        return [ 'title'=>sanitize_text_field($n['title']), 'number'=>absint($n['number']), 'cat'=>absint($n['cat']) ];
    }
    public function widget($args,$ins){
        $title = !empty($ins['title']) ? $ins['title'] : __('Pilihan Editor','newspulse');
        $number= !empty($ins['number'])? absint($ins['number']) : 5;
        $cat   = !empty($ins['cat']) ? absint($ins['cat']) : 0;
        echo $args['before_widget'];
        if ($title) echo $args['before_title'] . esc_html($title) . $args['after_title'];
        $q_args = ['posts_per_page'=>$number,'ignore_sticky_posts'=>false];
        if ($cat){ $q_args['cat'] = $cat; $q_args['ignore_sticky_posts'] = true; }
        else { $q_args['post__in'] = get_option('sticky_posts'); $q_args['orderby']='post__in'; }
        $q = new WP_Query($q_args);
        if ($q->have_posts()){
            echo '<ul class="np-popular-list">';
            while($q->have_posts()){ $q->the_post();
                echo '<li class="np-popular-item"><a class="np-popular-link" href="'.esc_url(get_permalink()).'"><span class="np-title">'.esc_html(get_the_title()).'</span></a></li>';
            }
            echo '</ul>';
            wp_reset_postdata();
        } else {
            echo '<p>'.esc_html__('Belum ada pilihan.', 'newspulse').'</p>';
        }
        echo $args['after_widget'];
    }
}

// Most Commented (last 30 days)
class Newspulse_Most_Commented_Widget extends WP_Widget {
    public function __construct(){ parent::__construct('newspulse_most_commented', __('Newspulse: Terbanyak Komentar', 'newspulse'), ['description'=>__('Artikel dengan komentar terbanyak 30 hari terakhir.', 'newspulse')]); }
    public function form($i){ $title = $i['title'] ?? __('Terbanyak Komentar','newspulse'); $number= isset($i['number'])? absint($i['number']) : 5; ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Judul:', 'newspulse'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
        <p><label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Jumlah:', 'newspulse'); ?></label>
        <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" min="1" max="10" value="<?php echo esc_attr($number); ?>" /></p>
    <?php }
    public function update($n,$o){ return ['title'=>sanitize_text_field($n['title']),'number'=>absint($n['number'])]; }
    public function widget($args,$i){
        $title = $i['title'] ?? __('Terbanyak Komentar','newspulse');
        $number= isset($i['number'])? absint($i['number']) : 5;
        echo $args['before_widget']; if ($title) echo $args['before_title'].esc_html($title).$args['after_title'];
        $q = new WP_Query([
            'posts_per_page'=>$number,
            'orderby'=>'comment_count',
            'order'=>'DESC',
            'date_query'=>[['after'=>'30 days ago']],
            'ignore_sticky_posts'=>true,
        ]);
        if ($q->have_posts()){
            echo '<ul class="np-popular-list">';
            while($q->have_posts()){ $q->the_post(); echo '<li class="np-popular-item"><a class="np-popular-link" href="'.esc_url(get_permalink()).'"><span class="np-title">'.esc_html(get_the_title()).'</span></a></li>'; }
            echo '</ul>'; wp_reset_postdata();
        }
        echo $args['after_widget'];
    }
}

// Latest Videos (by post format)
class Newspulse_Latest_Videos_Widget extends WP_Widget {
    public function __construct(){ parent::__construct('newspulse_latest_videos', __('Newspulse: Video Terbaru', 'newspulse'), ['description'=>__('Tampilkan artikel dengan format Video.', 'newspulse')]); }
    public function form($i){ $title=$i['title']??__('Video Terbaru','newspulse'); $number=isset($i['number'])?absint($i['number']):4; ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Judul:', 'newspulse'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
        <p><label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Jumlah:', 'newspulse'); ?></label>
        <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" min="1" max="10" value="<?php echo esc_attr($number); ?>" /></p>
    <?php }
    public function update($n,$o){ return ['title'=>sanitize_text_field($n['title']),'number'=>absint($n['number'])]; }
    public function widget($args,$i){
        $title=$i['title']??__('Video Terbaru','newspulse'); $number=isset($i['number'])?absint($i['number']):4;
        echo $args['before_widget']; if($title) echo $args['before_title'].esc_html($title).$args['after_title'];
        $q=new WP_Query([
            'posts_per_page'=>$number,
            'tax_query'=>[['taxonomy'=>'post_format','field'=>'slug','terms'=>['post-format-video']]],
            'ignore_sticky_posts'=>true,
        ]);
        if($q->have_posts()){
            echo '<ul class="np-popular-list">';
            while($q->have_posts()){ $q->the_post(); echo '<li class="np-popular-item"><a class="np-popular-link" href="'.esc_url(get_permalink()).'"><span class="np-title">▶ '.esc_html(get_the_title()).'</span></a></li>'; }
            echo '</ul>'; wp_reset_postdata();
        }
        echo $args['after_widget'];
    }
}

// Social follow (uses theme social links)
class Newspulse_Social_Follow_Widget extends WP_Widget {
    public function __construct(){ parent::__construct('newspulse_social_follow', __('Newspulse: Ikuti Kami', 'newspulse'), ['description'=>__('Tampilkan ikon sosial dari pengaturan tema.', 'newspulse')]); }
    public function form($i){ $title=$i['title']??__('Ikuti Kami','newspulse'); ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Judul:', 'newspulse'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
    <?php }
    public function update($n,$o){ return ['title'=>sanitize_text_field($n['title'])]; }
    public function widget($args,$i){ $title=$i['title']??__('Ikuti Kami','newspulse'); echo $args['before_widget']; if($title) echo $args['before_title'].esc_html($title).$args['after_title']; if(function_exists('newspulse_social_links')){ newspulse_social_links('footer'); } echo $args['after_widget']; }
}

// Topics widget (top categories or selected)
class Newspulse_Topics_Widget extends WP_Widget {
    public function __construct(){
        parent::__construct('newspulse_topics', __('Newspulse: Topik Utama', 'newspulse'), ['description'=>__('Tampilkan kategori/topik utama.', 'newspulse')]);
    }
    public function form($instance){
        $title = isset($instance['title']) ? $instance['title'] : __('Topik Utama', 'newspulse');
        $cats = isset($instance['cats']) ? $instance['cats'] : '';
        $count = isset($instance['count']) ? absint($instance['count']) : 6;
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Judul:', 'newspulse'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cats')); ?>"><?php esc_html_e('Kategori (ID, koma, opsional):', 'newspulse'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('cats')); ?>" name="<?php echo esc_attr($this->get_field_name('cats')); ?>" type="text" value="<?php echo esc_attr($cats); ?>" placeholder="1,2,3" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('count')); ?>"><?php esc_html_e('Jumlah topik:', 'newspulse'); ?></label>
            <input id="<?php echo esc_attr($this->get_field_id('count')); ?>" name="<?php echo esc_attr($this->get_field_name('count')); ?>" type="number" value="<?php echo esc_attr($count); ?>" min="1" max="12" />
        </p>
        <?php
    }
    public function update($new,$old){
        return [
            'title' => sanitize_text_field($new['title']),
            'cats'  => sanitize_text_field($new['cats']),
            'count' => absint($new['count'])
        ];
    }
    public function widget($args,$instance){
        $title = isset($instance['title']) ? $instance['title'] : __('Topik Utama', 'newspulse');
        $cats  = isset($instance['cats']) ? trim($instance['cats']) : '';
        $count = isset($instance['count']) ? absint($instance['count']) : 6;
        echo $args['before_widget'];
        if ($title) echo $args['before_title'] . esc_html($title) . $args['after_title'];
        if ($cats) {
            $ids = array_filter(array_map('absint', explode(',', $cats)));
            $terms = get_terms(['taxonomy'=>'category','include'=>$ids,'hide_empty'=>false]);
        } else {
            $terms = get_terms(['taxonomy'=>'category','number'=>$count,'orderby'=>'count','order'=>'DESC']);
        }
        if (!is_wp_error($terms) && $terms){
            echo '<ul class="np-topics">';
            foreach($terms as $t){
                echo '<li><a href="' . esc_url(get_term_link($t)) . '">' . esc_html($t->name) . '</a></li>';
            }
            echo '</ul>';
        }
        echo $args['after_widget'];
    }
}

// Newsletter CTA widget
class Newspulse_Newsletter_Widget extends WP_Widget {
    public function __construct(){
        parent::__construct('newspulse_newsletter', __('Newspulse: Newsletter CTA', 'newspulse'), ['description'=>__('Ajakan singkat untuk berlangganan atau mengikuti sosial.', 'newspulse')]);
    }
    public function form($instance){
        $title = isset($instance['title']) ? $instance['title'] : __('Berlangganan', 'newspulse');
        $desc  = isset($instance['desc']) ? $instance['desc'] : __('Dapatkan update berita terbaru langsung ke email Anda.', 'newspulse');
        $btn   = isset($instance['btn']) ? $instance['btn'] : __('Subscribe', 'newspulse');
        $url   = isset($instance['url']) ? $instance['url'] : home_url('/subscribe');
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Judul:', 'newspulse'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('desc')); ?>"><?php esc_html_e('Deskripsi:', 'newspulse'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('desc')); ?>" name="<?php echo esc_attr($this->get_field_name('desc')); ?>" rows="3"><?php echo esc_textarea($desc); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn')); ?>"><?php esc_html_e('Teks Tombol:', 'newspulse'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('btn')); ?>" name="<?php echo esc_attr($this->get_field_name('btn')); ?>" type="text" value="<?php echo esc_attr($btn); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('url')); ?>"><?php esc_html_e('URL Tujuan:', 'newspulse'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('url')); ?>" name="<?php echo esc_attr($this->get_field_name('url')); ?>" type="url" value="<?php echo esc_attr($url); ?>" />
        </p>
        <?php
    }
    public function update($new,$old){
        return [
            'title'=> sanitize_text_field($new['title']),
            'desc' => wp_kses_post($new['desc']),
            'btn'  => sanitize_text_field($new['btn']),
            'url'  => esc_url_raw($new['url']),
        ];
    }
    public function widget($args,$instance){
        $title = isset($instance['title']) ? $instance['title'] : __('Berlangganan', 'newspulse');
        $desc  = isset($instance['desc']) ? $instance['desc'] : '';
        $btn   = isset($instance['btn']) ? $instance['btn'] : __('Subscribe', 'newspulse');
        $url   = isset($instance['url']) ? $instance['url'] : '#';
        echo $args['before_widget'];
        if ($title) echo $args['before_title'] . esc_html($title) . $args['after_title'];
        if ($desc) echo '<p class="np-news-desc">' . wp_kses_post($desc) . '</p>';
        echo '<p><a class="btn" href="' . esc_url($url) . '">' . esc_html($btn) . '</a></p>';
        echo $args['after_widget'];
    }
}

// Body class: flag AMP via ?amp=1
add_filter('body_class', function ($classes) {
    if (newspulse_is_amp()) {
        $classes[] = 'amp';
    }
    return $classes;
});
