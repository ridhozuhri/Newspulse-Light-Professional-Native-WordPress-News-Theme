<?php if (!defined('ABSPATH')) { exit; } ?>
    </main>
    <footer id="site-footer" class="site-footer" role="contentinfo">
        <div class="container footer-widgets">
            <div class="footer-col footer-about">
                <div class="brand">
                    <?php if (function_exists('the_custom_logo') && has_custom_logo()) { the_custom_logo(); } else { ?>
                        <a class="site-title" href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                    <?php } ?>
                </div>
                <p class="site-description"><?php echo wp_kses_post(get_theme_mod('newspulse_footer_desc', get_bloginfo('description'))); ?></p>
            </div>
            <div class="footer-col footer-links">
                <h3><?php echo esc_html(get_theme_mod('newspulse_footer_quick_title', __('Navigasi Cepat', 'newspulse'))); ?></h3>
                <?php wp_nav_menu(['theme_location' => 'footer', 'container' => false, 'menu_class' => 'footer-menu']); ?>
            </div>
            <div class="footer-col footer-social">
                <h3><?php echo esc_html(get_theme_mod('newspulse_footer_social_title', __('Ikuti Kami', 'newspulse'))); ?></h3>
                <?php if (function_exists('newspulse_social_links')) { newspulse_social_links('footer'); } ?>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <p><?php echo wp_kses_post(get_theme_mod('newspulse_footer_text', '© ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.')); ?></p>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
    </body>
    </html>
