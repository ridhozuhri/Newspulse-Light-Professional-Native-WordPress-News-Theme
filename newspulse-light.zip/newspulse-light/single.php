<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<div class="container single-wrap">
    <article id="post-<?php the_ID(); ?>" <?php post_class('single-article'); ?> role="article">
        <header class="single-header">
            <?php if (has_post_thumbnail()) : ?>
                <div class="single-featured">
                    <?php the_post_thumbnail('newspulse-hero'); ?>
                </div>
            <?php endif; ?>
            <h1 class="single-title"><?php the_title(); ?></h1>
            <div class="read-time-line">⏱️ <?php echo esc_html(newspulse_get_read_time_minutes()); ?> <?php esc_html_e('menit baca', 'newspulse'); ?></div>
            <div class="post-meta">
                <?php newspulse_posted_by(); ?> · <?php newspulse_posted_on(); ?>
                <?php
                $cats = get_the_category();
                if ($cats) {
                    echo ' · <span class="meta-cats">';
                    $out = [];
                    foreach ($cats as $c) { $out[] = '<a href="' . esc_url(get_category_link($c)) . '">' . esc_html($c->name) . '</a>'; }
                    echo implode(', ', $out);
                    echo '</span>';
                }
                ?>
            </div>
            <?php newspulse_breadcrumbs(); ?>
        </header>
        <div class="single-content">
            <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
        </div>
        <footer class="single-footer">
            <?php get_template_part('template-parts/ui/share', 'buttons'); ?>
        </footer>
    </article>

    <section class="related-posts">
        <h2><?php esc_html_e('Related Posts', 'newspulse'); ?></h2>
        <div class="related-grid">
            <?php
            $cats = wp_get_post_categories(get_the_ID());
            $rel = new WP_Query([
                'posts_per_page' => 3,
                'post__not_in'   => [get_the_ID()],
                'category__in'   => $cats,
            ]);
            if ($rel->have_posts()) :
                while ($rel->have_posts()) : $rel->the_post();
                    get_template_part('template-parts/content/card');
                endwhile; wp_reset_postdata();
            else :
                echo '<p>' . esc_html__('No related posts.', 'newspulse') . '</p>';
            endif;
            ?>
        </div>
    </section>
</div>
<?php get_footer();
