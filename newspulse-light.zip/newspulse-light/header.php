<?php
if (!defined('ABSPATH')) { exit; }
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php if ((is_home() || is_front_page()) && !newspulse_is_amp()) : ?>
        <?php get_template_part('template-parts/ui/ticker'); ?>
    <?php endif; ?>
    <header id="site-header" class="site-header" role="banner">
        <div class="container header-inner">
            <?php get_template_part('template-parts/layout/header', 'brand'); ?>
            <?php get_template_part('template-parts/layout/header', 'nav'); ?>
            <?php get_template_part('template-parts/layout/header', 'utils'); ?>
        </div>
    </header>
    <main id="main-content" class="site-main" role="main">
