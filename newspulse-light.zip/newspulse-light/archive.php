<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<div class="container content-with-sidebars">
    <aside class="sidebar sidebar-left" aria-label="Sidebar Kiri">
        <?php if (is_active_sidebar('sidebar-left')) { dynamic_sidebar('sidebar-left'); } ?>
    </aside>
    <div class="content-area">
        <header class="archive-header">
            <h1 class="archive-title"><?php echo esc_html(get_the_archive_title()); ?></h1>
            <?php newspulse_breadcrumbs(); ?>
        </header>
        <?php if (have_posts()) : ?>
            <section class="news-grid">
                <?php while (have_posts()) : the_post();
                    get_template_part('template-parts/content/card');
                endwhile; ?>
            </section>
            <nav class="pagination">
                <?php the_posts_pagination(['mid_size' => 2]); ?>
            </nav>
        <?php else : ?>
            <p><?php esc_html_e('Tidak ada artikel.', 'newspulse'); ?></p>
        <?php endif; ?>
    </div>
    <aside class="sidebar sidebar-right" aria-label="Sidebar Kanan">
        <?php if (is_active_sidebar('sidebar-1')) { dynamic_sidebar('sidebar-1'); } ?>
    </aside>
</div>
<?php get_footer();
